# Fresh-Animations-CEM-fork
 Fresh Animations is owned and created by FreshLX. I'm only rewriting for compatibility with CEM mod.

Original:

• Fresh Discord https://discord.gg/Wxs7JEPMrH

• Fresh Profile https://www.planetminecraft.com/member/freshlx/

• Fresh Animations https://www.planetminecraft.com/texture-pack/fresh-animations-v1-0/

• Support FreshLX! +perks & early access Ko-Fi https://ko-fi.com/freshlx
